import ContactSection from "@/components/sections/contact/contact";

const ContactPage = () => {
  return (
    <div className="my-8">
      <ContactSection />
    </div>
  );
};

export default ContactPage;
