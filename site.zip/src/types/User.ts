export enum UserRole {
  DEV = "dev",
  ADMIN = "admin",
  USER = "user",
}
