import withPWA from "next-pwa";

/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        port: "",
        hostname: "st3.depositphotos.com",
      },
      {
        protocol: "https",
        port: "",
        hostname: "casestudyphoenix.com",
      },
      {
        protocol: "https",
        port: "",
        hostname: "lh3.googleusercontent.com",
      },
      {
        protocol: "https",
        port: "",
        hostname: "encrypted-tbn3.gstatic.com",
      },
    ],
  },
  reactStrictMode: true,
  pwa: {
    dest: "public",
    disable: process.env.NODE_ENV === "development",
    register: true,
    skipWaiting: true,
  },
  webpack(config, { isServer }) {
    if (!isServer) {
      const { GenerateSW } = require("workbox-webpack-plugin");

      config.plugins.push(
        new GenerateSW({
          mode:
            process.env.NODE_ENV === "development"
              ? "development"
              : "production",
          cacheId: "your-app-name",
          skipWaiting: true,
          clientsClaim: true,
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/your-api-url\//,
              handler: "NetworkFirst",
              options: {
                cacheName: "api-cache",
                expiration: {
                  maxEntries: 50,
                  maxAgeSeconds: 300,
                },
              },
            },
          ],
        })
      );
    }
    return config;
  },
};

export default withPWA(nextConfig);
